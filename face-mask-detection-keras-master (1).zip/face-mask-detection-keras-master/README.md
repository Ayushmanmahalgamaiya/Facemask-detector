# face-mask-detection-keras

This project is implemented in Python using Keras, Tensorflow and OpenCV.

## Credits and Links

The original dataset is prepared by [Prajna Bhandary](https://www.linkedin.com/in/prajna-bhandary-0b03a416a/) and available at [Github](https://github.com/prajnasb/observations/tree/master/experiements/data)

## Motivated by the works of,

1. [Adrian Rosebrock](https://www.pyimagesearch.com/2020/05/04/covid-19-face-mask-detector-with-opencv-keras-tensorflow-and-deep-learning/)
2. [sentdex](https://pythonprogramming.net/convolutional-neural-network-deep-learning-python-tensorflow-keras/)
3. [Prajna Bhandary](https://github.com/prajnasb/observations/tree/master/experiements/data)
